#include "ThreadedSpaceWireRw.h"

#pragma pack(push, 1)
typedef struct {
	u_char originAddr ;
	u_char packetNo ;
	struct timespec originTime ;
} th_packet_hdr_t;
#pragma pack(pop)

struct timespec sentPointTime[256] ;

void *readerProc(void *arg) {
	u_char packet[TH_MAX_PACKET_LEN] ;
	size_t wrongPackets = 0 ;
	u_char packetNo[256] = {0} ;
	th_packet_hdr_t *pHdr ;

	pHdr = (th_packet_hdr_t*)&packet[0] ;

	TRACE("Start reading...\n") ;

	// Just print the received data...
	while(true) {
		bool connected = pReader->isConnected() ;
		if (connected) {
			DTRACE("CONNECTED\n") ;

            int nBytes = 0 ;
            nBytes = pReader->recv(packet, sizeof(packet)) ;
            DTRACE("<- Received a packet size=%i, from addr=%i, firts 32 bytes:\n", nBytes, pHdr->originAddr) ;
            if (nBytes > 0) {
                // Dump first 16 bytes
#ifdef DEBUG
                hexdump(packet, 32) ;
#endif
                u_char fromAddr = pHdr->originAddr ;

#ifdef CHECK_RECEIVED_PACKET
                if ( !checkPacket(packetNo[fromAddr]++, packet, sizeof(packet)) ) {	// WRONG
                    wrongPackets ++ ;
                }
#endif
#ifdef REPLY_ON_PACKET

                pHdr->originAddr = readerAddr[0] ;
                DTRACE("-> Send reply: toAddr=%i, packetNo=%i, size=%u\n", fromAddr, pHdr->packetNo, sizeof(th_packet_hdr_t)) ;
                pReader->sendTo(&fromAddr, packet, sizeof(th_packet_hdr_t)) ;
#endif
            }
		} else {
			DTRACE("DISCONNECTED\n") ;
#ifdef ENABLE_READER_DISCONNECTED_SNOOZE
            SNOOZE(TH_READER_DISCONNECTED_SNOOZE_TIME_MS) ;
#endif
		}
		DTRACE("wrongPackets=%u\n", wrongPackets) ;
	}
	return NULL ;
}

void *writerProc(void *arg) {
	u_char packet[TH_MAX_PACKET_LEN] ;
	size_t frameNo = 0;
	u_char packetNo = 0;
	u_int wrongPackets = 0 ;
	struct timespec tsend, trecv ;
	th_packet_hdr_t *pHdr ;
	u_char	*pData ;

	pHdr = (th_packet_hdr_t*)&packet[0] ;
	pData = &packet[sizeof(th_packet_hdr_t)] ;

    TRACE("Setting up speed to %iMbit/s\n", WRITER_RATE) ;
    int stat = pWriter->setTxSpeed(WRITER_RATE) ;
    TRACE("setTxSpeed() returned %i\n", stat) ;

	TRACE("Start writing...\n") ;
	while (true) {
		DTRACE("========== Frame %u ===========\n", frameNo++) ;

		pHdr->originAddr = writerAddr[0] ;
#ifdef FILL_WRITER_PACKET
		// Fill the data buffer
		pHdr->packetNo = packetNo ;
		for (size_t i = 0; i < TH_MAX_PACKET_LEN-sizeof(th_packet_hdr_t); i++) {
			pData[i] = pData[i-1] +1 ;
		}
#endif
		bool connected = pWriter->isConnected() ;

		if ( connected ) {
			// If the connection is established print status and send
			// some data...

			DTRACE ("CONNECTED\n") ;

			DTRACE("-> Send a packet no=%i size=%u\n", packetNo, sizeof(packet)) ;
			//hexdump(data, sizeof(data)) ;
			clock_gettime(CLOCK_REALTIME, &tsend) ;	// begin point of time
			pHdr->originTime = tsend ;
			if ( pWriter->sendTo(readerAddr, packet, sizeof(packet)) == -1 ) {
				fprintf(stderr, "writerProc(): Sending ERROR, write() returned -1\n") ;
			}
			clock_gettime(CLOCK_REALTIME, &tsend) ;	// begin point of time
			sentPointTime[packetNo] = tsend ;
#if defined(REPLY_ON_PACKET) && defined(RECEIVE_REPLY_SYNC)
			int nBytes = pWriter->recv(packet, sizeof(packet)) ;
			if (nBytes > 0) {
				clock_gettime(CLOCK_REALTIME, &trecv) ; // end point of time
				float delta = (trecv.tv_nsec - pHdr->originTime.tv_nsec) / 1000000.0 + (trecv.tv_sec - pHdr->originTime.tv_sec)*1000.0 ;
				DTRACE("<- Received a reply size=%i, from addr=%i, sendRecvTime=%f ms\n", nBytes, pHdr->originAddr, delta) ;
				if ( !checkPacket(packetNo, packet, sizeof(packet)) ) {	// WRONG
				     wrongPackets ++ ;
				}
				DTRACE("wrongPackets=%u\n", wrongPackets) ;
			} else {
				DTRACE("<- Receiving a reply is FAIL\n") ;
			}
#endif	// REPLY_ON_PACKET && RECEIVE_REPLY_SYNC
		} else {
			// If disconnected print that.
			DTRACE ("DISCONNECTED\n") ;
		}

#ifdef ENABLE_WRITER_SNOOZE
		// Wait a while
		SNOOZE(TH_WRITER_SNOOZE_TIME_MS) ;
#endif

		packetNo ++ ;
	}
	return NULL ;
}

#if defined(REPLY_ON_PACKET) && defined(RECEIVE_REPLY_ASYNC)
void *replyCheckerProc(void *arg) {
	struct timespec trecv ;
	u_int wrongPackets = 0 ;
	u_char packet[TH_MAX_PACKET_LEN] ;
	th_packet_hdr_t	*pHdr ;
	u_char packetNo = 0 ;

	pHdr = (th_packet_hdr_t*)&packet[0] ;

	while(true) {
		int nBytes = pWriter->recv(packet, sizeof(packet)) ;
		if (nBytes > 0) {
			clock_gettime(CLOCK_REALTIME, &trecv) ; // end point of time
			float deltaOrigin = (trecv.tv_nsec - pHdr->originTime.tv_nsec) / 1000000.0 + (trecv.tv_sec - pHdr->originTime.tv_sec)*1000.0 ;
			float deltaSent = (trecv.tv_nsec - sentPointTime[pHdr->packetNo].tv_nsec) / 1000000.0 + (trecv.tv_sec - sentPointTime[pHdr->packetNo].tv_sec)*1000.0 ;
			DTRACE("<- Received a reply size=%i, from addr=%i\n", nBytes, pHdr->originAddr) ;
            DTRACE("send-reply-time=%f ms, reply-time=%f ms\n", deltaOrigin, deltaSent) ;
			if ( !checkPacket(packetNo, packet, sizeof(packet)) ) {	// WRONG
				wrongPackets ++ ;
			}
			DTRACE("wrongPackets=%u\n", wrongPackets) ;
		}
		packetNo++ ;
	}

	return NULL ;
}
#endif

void hexdump ( u_char buf[], size_t len ) {
	for ( size_t i = 0; i < len; i++ ) {
		printf("0x%X ", buf[i]) ;
	}
	printf("\n") ;
}

bool checkPacket(u_char packetNo, u_char buf[], size_t len) {
	if ( buf[1] != packetNo ) {
		DTRACE("Wrong packet no=%i, expectedNo=%i\n", buf[1], packetNo) ;
		return false ;
	} else {
		DTRACE("The packet is OK, no=%i, expectedNo=%i\n", buf[1], packetNo) ;
	}

	/*for (size_t i = 2; i < len -1 ; i++) {
		if ( (u_char)(buf[i] + 1) != buf[i+1]) {
			DTRACE("Sequence missmatch: buf[%li]=%i, buf[%li+1]=%i\n", i, buf[i], i, buf[i+1]) ;
			return false ;
		}
	}*/
	return true ;
}

void *timeCodeReceiverProc(void *arg) {
    while(true) {
        u_char time = pReader->waitTimeCode() ;
        DTRACE("Received TimeCode=%i\n", time) ;
    }
}
