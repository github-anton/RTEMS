/*
 * CSpaceWire_test.cpp
 *
 *  Created on: 28 нояб. 2017 г.
 *      Author: anton
 */

#if 0
#   define DEBUG
#endif

#include "CMcSpaceWire.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "aux.h"

#define WRITER_DEV_PATH		"/dev/spw0"
#define READER_DEV_PATH		"/dev/spw1"

CMcSpaceWire *pReader = NULL ;
CMcSpaceWire *pWriter = NULL ;

#define PACKETS     500

void hexdump ( u_char buf[], size_t len ) ;

u_char inData[4096] ;
u_char outData[4096] ;

int main(void) {
    
	pWriter = new CMcSpaceWire(WRITER_DEV_PATH, 4096, 0) ;
    if (!pWriter->isOk()) {
        return -1 ;
    }

	pReader = new CMcSpaceWire(READER_DEV_PATH, 4096, 0) ;
    if (!pReader->isOk()) {
        return -1 ;
    }
	
    TRACE("Waiting for connection...\n") ;
    bool writerConnected ;
    bool readerConnected ;
    do {
        SNOOZE(1000) ;
        readerConnected = pWriter->isConnected() ;
        writerConnected = pReader->isConnected() ;
    } while (!readerConnected || !writerConnected) ;
    TRACE("CONNECTED\n") ;
    
    TRACE("Setting up speed to 200Mbit/s\n") ;
    int stat = pWriter->setTxSpeed(200) ;
    TRACE("setTxSpeed() returned %i\n", stat) ;
    
    TRACE("Calculating speed...\n") ;
    struct timespec tstart, tstop ;
    clock_gettime(CLOCK_REALTIME, &tstart) ;
    for (int i = 0; i < PACKETS; i++) {
       
        DTRACE("-> Sending a packet size=%i...\n", sizeof(outData)) ;
		if ( pWriter->sendTo(NULL, outData, sizeof(outData)) == -1 ) {
            DTRACE("-> Sending FAIL, write() returned -1\n") ;
        } else {
            DTRACE("-> Sending is OK\n") ;
            DTRACE("First sent 16 bytes:\n") ;
#ifdef DEBUG
            hexdump(outData, 16) ;
#endif
        }
		
		DTRACE("<- Receiving packet...\n") ;
        int nBytes = pReader->recv(inData, sizeof(inData)) ;
        if(nBytes == -1) {
            DTRACE("<- Receiving FAIL, recv() returned -1\n");
        } else {
            DTRACE("<- Receiving is OK, len=%i\n", nBytes) ;
            DTRACE("Received first 16 bytes:\n") ;
#ifdef DEBUG
            hexdump(inData, 16) ;
#endif
        }
    }
    clock_gettime(CLOCK_REALTIME, &tstop) ;
	float delta = (tstop.tv_nsec - tstart.tv_nsec) / 1000000000.0 + (tstop.tv_sec - tstart.tv_sec) ;
	TRACE("%.2f Kb/s\n", 4 * PACKETS / delta) ;

	return 0 ;
}

void hexdump ( u_char buf[], size_t len ) {
	for ( size_t i = 0; i < len; i++ ) {
		printf("0x%X ", buf[i]) ;
	}
	printf("\n") ;
}
