#include "ThreadedSpaceWireRw.h"

void *readerProc(void *arg) {
	u_char data[TH_MAX_PACKET_LEN - 1] ;
	size_t wrongPackets = 0 ;
	u_char packetNo[256] = {0} ;

	TRACE("Start reading...\n") ;

	// Just print the received data...
	while(true) {
		bool connected = pReader->isConnected() ;
		if (connected) {
			DTRACE("CONNECTED\n") ;

            int nBytes = 0 ;
            nBytes = pReader->recv(data, sizeof(data)) ;
            DTRACE("<- Received a packet size=%i, from addr=%i, firts 16 bytes:\n", nBytes, data[0]) ;
            if (nBytes > 0) {
                // Dump first 16 bytes
#ifdef DEBUG
                hexdump(data, 16) ;
#endif
                u_char fromAddr = data[0] ;

#ifdef CHECK_RECEIVED_PACKET
                if ( !checkPacket(packetNo[fromAddr]++, data, sizeof(data)) ) {	// WRONG
                    wrongPackets ++ ;
                }
#endif
#ifdef REPLY_ON_PACKET

                data[0] = readerAddr[0] ;
                pReader->sendTo(&fromAddr, data, 2) ;
#endif
            }
		} else {
			DTRACE("DISCONNECTED\n") ;
            sleep(1) ;
		}
		DTRACE("wrongPackets=%u\n", wrongPackets) ;
	}
	return NULL ;
}

void *writerProc(void *arg) {
	u_char data[TH_MAX_PACKET_LEN-1] ;
	size_t frameNo = 0;
	u_char packetNo = 0;
	size_t wrongPackets = 0 ;
	struct timespec tstart, tstop ;

	TRACE("Start writing...\n") ;
	while (true) {
		DTRACE("Frame %u\n", frameNo++) ;

		data[0] = writerAddr[0] ;
#ifdef FILL_WRITER_PACKET
		// Fill the data buffer
		data[1] = packetNo ;
		for (size_t i = 2; i < TH_MAX_PACKET_LEN-2; i++) {
			data[i] = data[i-1] +1 ;
		}
#endif
		bool connected = pWriter->isConnected() ;

		if ( connected ) {
			// If the connection is established print status and send
			// some data...

			DTRACE ("CONNECTED\n") ;

			DTRACE("-> Send a packet no=%i size=%u\n", packetNo, sizeof(data)) ;
			//hexdump(data, sizeof(data)) ;
			clock_gettime(CLOCK_REALTIME, &tstart) ;	// begin point of time
			if ( pWriter->sendTo(readerAddr, data, sizeof(data)) == -1 ) {
				fprintf(stderr, "writerProc(): Sending ERROR, write() returned -1\n") ;
			}
#ifdef REPLY_ON_PACKET
			int nBytes = pWriter->recv(data, sizeof(data)) ;
			if (nBytes > 0) {
				clock_gettime(CLOCK_REALTIME, &tstop) ; // end point of time
				float delta = (tstop.tv_nsec - tstart.tv_nsec) / 1000000.0 + (tstop.tv_sec - tstart.tv_sec)*1000.0 ;
				DTRACE("<- Received a reply size=%i, from addr=%i, sendRecvTime=%f ms\n", nBytes, data[0], delta) ;
				if ( !checkPacket(packetNo, data, sizeof(data)) ) {	// WRONG
				     wrongPackets ++ ;
				}
				DTRACE("wrongPackets=%u\n", wrongPackets) ;
			} else {
				DTRACE("<- Receiving a reply is FAIL\n") ;
			}
#endif	// REPLY_ON_PACKET
		} else {
			// If disconnected print that.
			DTRACE ("DISCONNECTED\n") ;
		}

#ifdef ENABLE_WRITER_SNOOZE
		// Wait a while
		SNOOZE(20) ;
#endif

		packetNo ++ ;
	}
	return NULL ;
}

void hexdump ( u_char buf[], size_t len ) {
	for ( size_t i = 0; i < len; i++ ) {
		printf("0x%X ", buf[i]) ;
	}
	printf("\n") ;
}

bool checkPacket(u_char packetNo, u_char buf[], size_t len) {
	if ( buf[1] != packetNo ) {
		DTRACE("Wrong packet no=%i, expectedNo=%i\n", buf[1], packetNo) ;
		return false ;
	} else {
		DTRACE("The packet is OK, no=%i, expectedNo=%i\n", buf[1], packetNo) ;
	}

	/*for (size_t i = 2; i < len -1 ; i++) {
		if ( (u_char)(buf[i] + 1) != buf[i+1]) {
			DTRACE("Sequence missmatch: buf[%li]=%i, buf[%li+1]=%i\n", i, buf[i], i, buf[i+1]) ;
			return false ;
		}
	}*/
	return true ;
}
