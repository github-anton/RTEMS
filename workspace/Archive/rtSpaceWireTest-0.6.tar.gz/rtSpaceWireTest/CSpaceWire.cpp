/*
 * CAbstractSpaceWire.cpp
 *
 *  Created on: 31 янв. 2018 г.
 *      Author: anton
 */

#include "CSpaceWire.h"

CSpaceWire::CSpaceWire() {
	// TODO Auto-generated constructor stub

}

CSpaceWire::~CSpaceWire() {
	// TODO Auto-generated destructor stub
}

